from flask import Flask, render_template, request, jsonify
import subprocess
import os

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)  # Create uploads folder if it doesn't exist

# Route for the homepage
@app.route('/')
def home():
    return render_template('index.html')

# Route to upload Excel file
@app.route('/upload_excel', methods=['POST'])
def upload_excel():
    if 'file' not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file = request.files['file']

    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    if not file.filename.endswith(('.xls', '.xlsx')):
        return jsonify({"error": "Invalid file type. Please upload an Excel file."}), 400

    # Save the file
    file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(file_path)

    return jsonify({"message": f"File uploaded successfully: {file.filename}", "file_path": file_path})

# Route to create a new project
@app.route('/create_project', methods=['POST'])
def create_project():
    try:
        if request.is_json:
            data = request.get_json()  # Get the JSON data from the request
            file_path = data.get('file_path')  # Get the file path from the request

            if not file_path:
                return jsonify({"error": "No file path provided"}), 400

            # Pass the file path to the Python script
            subprocess.run(["python", "create_new_project.py", file_path], check=True)

            return jsonify({"message": "New project created successfully!"})
        else:
            return jsonify({"error": "Request must be in JSON format"}), 415

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Route to edit an old project
@app.route('/edit_project', methods=['POST'])
def edit_project():
    try:
        if request.is_json:
            data = request.get_json()  # Get the JSON data from the request
            file_path = data.get('file_path')  # Get the file path from the request

            if not file_path:
                return jsonify({"error": "No file path provided"}), 400

            # Pass the file path to the Python script
            subprocess.run(["python", "edit_old_project.py", file_path], check=True)

            return jsonify({"message": "edit  project created successfully! "})
        else:
            return jsonify({"error": "Request must be in JSON format"}), 415

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True)
