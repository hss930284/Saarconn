import sys
import os

# Ensure the script is getting the file path
if len(sys.argv) < 2:
    print("Error: File path argument is missing.")
    sys.exit(1)

file_path = sys.argv[1]  # Capture the file path passed from Flask

# Check if the file exists at the provided path
if not os.path.exists(file_path):
    print(f"Error: The file at {file_path} does not exist.")
    sys.exit(1)

# If the file exists, just print the file path
print(f"Processing file at: {file_path}")
